#!/usr/bin/env python3
"""구형 .hwp(HWP5)의 본문 글자를 뽑는다(외부 패키지 없이). 표 안 글자는 들여쓰기로 구분한다.
사용: python3 -I hwp_글자추출.py <입력.hwp> <출력.txt>"""
import sys,struct,zlib
d=open(sys.argv[1],'rb').read()
assert d[:8]==bytes.fromhex('D0CF11E0A1B11AE1'),'OLE 아님'
ss=1<<struct.unpack_from('<H',d,30)[0]; mss=1<<struct.unpack_from('<H',d,32)[0]
nfat,dirstart,cutoff,mfstart,nmf,difstart,ndif=struct.unpack_from('<IIIIIII',d,44)[0],struct.unpack_from('<I',d,48)[0],struct.unpack_from('<I',d,56)[0],struct.unpack_from('<I',d,60)[0],struct.unpack_from('<I',d,64)[0],struct.unpack_from('<I',d,68)[0],struct.unpack_from('<I',d,72)[0]
sec=lambda n:d[512+n*ss:512+(n+1)*ss]
dif=list(struct.unpack_from('<109I',d,76))
s=difstart
for _ in range(ndif):
    b=sec(s); v=struct.unpack('<%dI'%(ss//4),b); dif+=v[:-1]; s=v[-1]
fat=[]
for n in dif:
    if n>=0xFFFFFFFA: continue
    fat+=struct.unpack('<%dI'%(ss//4),sec(n))
def chain(start,table=fat):
    out=[];n=start
    while n<0xFFFFFFFA and len(out)<10**7: out.append(n); n=table[n]
    return out
def read(start):return b''.join(sec(n) for n in chain(start))
dirs=read(dirstart); ents=[]
for i in range(len(dirs)//128):
    e=dirs[i*128:(i+1)*128]; nl=struct.unpack_from('<H',e,64)[0]
    name=e[:max(0,nl-2)].decode('utf-16le','ignore'); typ=e[66]; l,r,c=struct.unpack_from('<III',e,68); st=struct.unpack_from('<I',e,116)[0]; sz=struct.unpack_from('<Q',e,120)[0]
    ents.append(dict(name=name,typ=typ,l=l,r=r,c=c,st=st,sz=sz))
root=ents[0]; mini=read(root['st']); mfat=[]
for n in chain(mfstart): mfat+=struct.unpack('<%dI'%(ss//4),sec(n))
def stream(e):
    if e['sz']<cutoff:
        return b''.join(mini[n*mss:(n+1)*mss] for n in chain(e['st'],mfat))[:e['sz']]
    return read(e['st'])[:e['sz']]
def kids(i):
    out=[]
    def walk(n):
        if n==0xFFFFFFFF or n>=len(ents): return
        walk(ents[n]['l']); out.append(n); walk(ents[n]['r'])
    walk(ents[i]['c']); return out
by={}
for i in kids(0):
    by[ents[i]['name']]=i
flags=struct.unpack_from('<I',stream(ents[by['FileHeader']]),36)[0]; comp=flags&1; assert not flags&2,'암호화'
body=ents[by['BodyText']]; secs=sorted((ents[i] for i in kids(by['BodyText'])),key=lambda e:int(e['name'][7:]) if e['name'][7:].isdigit() else 0)
out=[]
for e in secs:
    data=stream(e)
    if comp: data=zlib.decompress(data,-15)
    p=0;n=len(data)
    while p+4<=n:
        h=struct.unpack_from('<I',data,p)[0]; tag=h&0x3ff; lvl=(h>>10)&0x3ff; sz=h>>20; p+=4
        if sz==0xfff: sz=struct.unpack_from('<I',data,p)[0]; p+=4
        rec=data[p:p+sz]; p+=sz
        if tag==67:
            t=[];i=0
            while i+2<=len(rec):
                c=struct.unpack_from('<H',rec,i)[0]; i+=2
                if c in (10,13): t.append('\n')
                elif c<32:
                    if c in (1,2,3,4,5,6,7,8,9,11,12,14,15,16,17,18,19,20,21,22,23): i+=14
                    if c==9: t.append(' ')
                else: t.append(chr(c))
            s=''.join(t).strip()
            if s: out.append('    '*max(0,lvl-1)+f'[L{lvl}] '+s.replace('\n',' / '))
open(sys.argv[2],'w',encoding='utf8').write('\n'.join(out)+'\n'); print(len(out),'문단')
