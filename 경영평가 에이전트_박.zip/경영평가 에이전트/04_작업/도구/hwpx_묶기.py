#!/usr/bin/env python3
"""풀어 둔 HWPX 폴더를 .hwpx로 묶는다. mimetype을 압축 없이 맨 앞에 넣고, 모든 XML이 파싱되는지 확인한다.
사용: python3 -I hwpx_묶기.py <풀어둔폴더> <출력.hwpx>
풀기:  unzip -o 원본.hwpx -d 풀어둔폴더"""
import sys, os, zipfile
from lxml import etree
src,dst=sys.argv[1:3]
files=[os.path.relpath(os.path.join(r,f),src).replace(os.sep,'/') for r,_,fs in os.walk(src) for f in fs]
assert 'mimetype' in files, 'mimetype 없음'
for f in files:
    if f.endswith(('.xml','.hpf','.rdf')): etree.parse(os.path.join(src,f))
with zipfile.ZipFile(dst,'w') as z:
    z.write(os.path.join(src,'mimetype'),'mimetype',zipfile.ZIP_STORED)
    for f in sorted(files):
        if f!='mimetype': z.write(os.path.join(src,f),f,zipfile.ZIP_DEFLATED)
print('OK',dst,len(files),'files')
