#!/usr/bin/env python3
"""HWPX의 모든 글자를 문단 단위로 뽑아 확인용 txt로 저장한다 (수치 대조·검수용).
사용: python3 -I hwpx_글자추출.py <입력.hwpx> <출력.txt>"""
import sys, zipfile
from lxml import etree
NS={'hp':'http://www.hancom.co.kr/hwpml/2011/paragraph'}
z=zipfile.ZipFile(sys.argv[1]); out=[]
for n in sorted(x for x in z.namelist() if x.startswith('Contents/section')):
    out.append('=== '+n)
    for p in etree.fromstring(z.read(n)).iter('{%s}p'%NS['hp']):
        t=''.join(p.xpath('./hp:run/hp:t/text()',namespaces=NS)).strip()
        if t: out.append(t)
open(sys.argv[2],'w',encoding='utf8').write('\n'.join(out)+'\n'); print(len(out),'lines')
