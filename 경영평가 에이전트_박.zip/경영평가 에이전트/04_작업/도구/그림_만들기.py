#!/usr/bin/env python3
"""시험본에 넣을 그래프·도식 PNG를 만든다. 숫자는 작년 보고서(양식)에 적힌 값만 쓴다.
사용: python3 -I 그림_만들기.py <출력폴더>"""
import sys, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
_F=["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc","/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"]
for f in _F:
    if os.path.exists(f): fm.fontManager.addfont(f)
_name=fm.FontProperties(fname=_F[0]).get_name()
plt.rcParams["font.family"]=[_name]; plt.rcParams["axes.unicode_minus"]=False
out=sys.argv[1]; os.makedirs(out,exist_ok=True)
DK,MD,LT,TX="#404040","#808080","#D9D9D9","#000000"

# 그림 1: 개방·제공 규모 (좌: 공공데이터 목록 개방, 우: 카카오 데이터셋 제공)
fig,(a,b)=plt.subplots(1,2,figsize=(9,3.3),dpi=200,gridspec_kw={"width_ratios":[1,1.15]})
bars=a.bar(["’24년까지","’25년"],[61,77],color=[LT,DK],width=0.5,edgecolor=MD)
for r,v in zip(bars,[61,77]): a.text(r.get_x()+r.get_width()/2,v+2,f"{v}개",ha="center",fontsize=12,fontweight="bold")
a.text(0.5,84,"+16개 (26.2%↑)",ha="center",fontsize=11,color=DK)
a.set_ylim(0,95); a.set_title("공공데이터 목록 개방",fontsize=12,pad=10,fontweight="bold"); a.set_yticks([])
bars=b.bar(["텍스트 콘텐츠","미디어 콘텐츠"],[8,11],color=[MD,DK],width=0.5)
for r,t in zip(bars,["약 8만 건","11만 건"]): b.text(r.get_x()+r.get_width()/2,r.get_height()+0.3,t,ha="center",fontsize=12,fontweight="bold")
b.set_ylim(0,13.5); b.set_title("카카오 AI 모델 학습용 데이터셋 제공 (협약 2회)",fontsize=12,pad=10,fontweight="bold"); b.set_yticks([])
for ax in (a,b):
    for s in ("top","right","left"): ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(MD); ax.tick_params(axis="x",labelsize=11,length=0)
fig.tight_layout(); fig.savefig(f"{out}/그림1_개방제공규모.png"); plt.close(fig)

# 그림 2: 개방-활용-환류 선순환 (작년 보고서 향후 개선과제 ① 내용)
fig,ax=plt.subplots(figsize=(9,2.6),dpi=200); ax.set_xlim(0,100); ax.set_ylim(0,30); ax.axis("off")
steps=[("수요 발굴","외부 요구\n실태조사 반영"),("우선 개방","고수요 데이터\n선별·집중 개방"),("활용 촉진","큐레이션·컨설팅\n표준화 기반 제공"),("성과 환류","전년도 평가 결과\n분석을 통한 환류")]
w,h,g=19,16,6.7; x0=(100-(4*w+3*g))/2
for i,(t,s) in enumerate(steps):
    x=x0+i*(w+g)
    ax.add_patch(FancyBboxPatch((x,8),w,h,boxstyle="round,pad=0.4,rounding_size=2",fc=DK if i in(0,3) else "#F2F2F2",ec=MD,lw=1.2))
    c="white" if i in(0,3) else TX
    ax.text(x+w/2,19.5,t,ha="center",va="center",fontsize=13,fontweight="bold",color=c)
    ax.text(x+w/2,13,s,ha="center",va="center",fontsize=9.5,color=c,linespacing=1.4)
    if i<3: ax.add_patch(FancyArrowPatch((x+w+0.8,16),(x+w+g-0.8,16),arrowstyle="-|>",mutation_scale=16,color=MD,lw=1.6))
xe=x0+3*(w+g)+w/2; xs=x0+w/2
ax.add_patch(FancyArrowPatch((xe,7.3),(xs,7.3),connectionstyle="arc3,rad=0.0",arrowstyle="-|>",mutation_scale=16,color=MD,lw=1.6,linestyle=(0,(4,3))))
ax.text(50,3.6,"수요 발굴 → 우선 개방 → 활용 촉진 → 성과 환류의 선순환 구조 체계화",ha="center",va="center",fontsize=10.5,color=DK)
fig.savefig(f"{out}/그림2_개방활용환류_선순환.png",bbox_inches="tight",pad_inches=0.08); plt.close(fig)
print("ok")
