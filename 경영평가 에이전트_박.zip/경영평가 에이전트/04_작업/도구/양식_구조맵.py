#!/usr/bin/env python3
"""HWPX 양식의 구조(문단·표·그림 위치와 글자)를 마크다운으로 뽑는다. 원본은 수정하지 않는다.
사용: python3 -I 양식_구조맵.py <입력.hwpx> <출력.md>"""
import sys, zipfile
from lxml import etree
NS={'hp':'http://www.hancom.co.kr/hwpml/2011/paragraph','hs':'http://www.hancom.co.kr/hwpml/2011/section'}
def txt(e): return ''.join(e.xpath('.//hp:t/text()',namespaces=NS)).strip()
src,dst=sys.argv[1:3]
z=zipfile.ZipFile(src); out=[f"# 구조맵: {src.split('/')[-1]}\n"]
for n in sorted(x for x in z.namelist() if x.startswith('Contents/section')):
    root=etree.fromstring(z.read(n)); ps=root.xpath('/hs:sec/hp:p',namespaces=NS)
    out.append(f"\n## {n} (최상위 문단 {len(ps)}개)\n\n|번호|표|그림|글자 미리보기|\n|--|--|--|--|")
    for i,p in enumerate(ps):
        t=len(p.xpath('.//hp:tbl',namespaces=NS)); g=len(p.xpath('.//hp:pic',namespaces=NS)); s=txt(p).replace('|','/')
        if t or g or s: out.append(f"|{i}|{t or ''}|{g or ''}|{s[:70]}|")
open(dst,'w',encoding='utf8').write('\n'.join(out)+'\n')
print(dst,len(out))
