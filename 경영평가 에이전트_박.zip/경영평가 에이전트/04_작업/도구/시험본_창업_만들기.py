#!/usr/bin/env python3
"""양식(HWPX)을 복제해 '창업 및 경제활성화' 시험본을 만든다. 양식의 기존 블록(0~46, 47~54)은 글자 외에는 건드리지 않는다.
사용: python3 -I 시험본_창업_만들기.py <양식.hwpx> <그림폴더> <출력.hwpx> <작업폴더>"""
import sys, os, copy, math, shutil, zipfile, subprocess
from lxml import etree
SRC, FIG, OUT, WORK = sys.argv[1:5]
NSM={'hp':'http://www.hancom.co.kr/hwpml/2011/paragraph','hs':'http://www.hancom.co.kr/hwpml/2011/section',
     'hc':'http://www.hancom.co.kr/hwpml/2011/core'}
HP='{%s}'%NSM['hp']
if os.path.exists(WORK): shutil.rmtree(WORK)
os.makedirs(WORK); zipfile.ZipFile(SRC).extractall(WORK)
sec_path=f"{WORK}/Contents/section1.xml"
tree=etree.parse(sec_path); root=tree.getroot()
ps=root.xpath('/hs:sec/hp:p',namespaces=NSM)
LOG=[]
def X(e,q): return e.xpath(q,namespaces=NSM)
def T(e): return ''.join(X(e,'.//hp:t/text()'))
def nolines(e):
    for l in X(e,'.//hp:linesegarray'): l.getparent().remove(l)
    return e
_uid=[2090000000]
def uid(): _uid[0]+=1; return str(_uid[0])
def frag(xml):
    decl=' '.join(f'xmlns:{k}="{v}"' for k,v in root.nsmap.items() if k)
    return etree.fromstring(f'<w {decl}>{xml}</w>')[0]

def cell(tbl,r,c):
    for tc in X(tbl,'.//hp:tc'):
        a=tc.find('hp:cellAddr',NSM)
        if a.get('rowAddr')==str(r) and a.get('colAddr')==str(c): return tc
    raise KeyError((r,c))
def set_cell_text(tc,text,ref_p=None):
    """셀의 첫 문단 글자를 바꾼다. 비어 있으면 ref_p(문단)를 복제해 넣는다."""
    sub=tc.find('hp:subList',NSM); first=sub.find('hp:p',NSM)
    ts=X(first,'.//hp:t')
    if ts:
        ts[0].text=text
        for t in ts[1:]: t.text=''
    elif ref_p is not None:
        for p in X(sub,'hp:p'): sub.remove(p)
        np_=nolines(copy.deepcopy(ref_p)); X(np_,'.//hp:t')[0].text=text
        for t in X(np_,'.//hp:t')[1:]: t.text=''
        sub.append(np_)
    else: raise ValueError('빈 셀인데 ref_p 없음')
    nolines(sub)
def replace_text(frm,to,count=1):
    n=0
    for e in root.iter():
        for attr in ('text','tail'):
            v=getattr(e,attr)
            if v and frm in v: setattr(e,attr,v.replace(frm,to)); n+=1
    assert n==count,(frm,n); LOG.append(f'글자 교정: {frm!r} → {to!r}')

# ── 1. 목차(블록 8) ───────────────────────────────────────────
T11='공공데이터 공유·활용 기반 구축을 위한 추진 체계 마련'
T12='개방 데이터의 민간 활용 지원 및 협업 활동 강화'
T13='성과 확산 및 환류 (역량 강화·홍보)'
toc=X(ps[8],'.//hp:tbl')[0]
for (r,txt) in ((8,'1.1 '+T11),(9,'1.2 '+T12),(10,'1.3 '+T13)):
    c=cell(toc,r,2); assert T(c).strip() in ('000','2. 000','3. 000'),T(c)
    set_cell_text(c,txt)
c=cell(toc,7,2); assert T(c).strip()=='000'
set_cell_text(c,T(X(ps[35],'.//hp:tc')[-1]) if False else '민간수요 맞춤형 개방체계 구축, 협업데이터 공동생산 협력체계 구축 등을 위한 노력과 성과')
LOG.append('목차: 평가내용 1 제목 및 1.1~1.3 제목 기입 (쪽번호 00은 그대로)')

# ── 2. Ⅲ 개선효과(블록 32) ─────────────────────────────────
t32=X(ps[32],'.//hp:tbl')[0]
c=cell(t32,1,3); assert T(c).strip()=='데이터 양적 확대 개방'
set_cell_text(c,' 데이터 양적 확대 개방 (+16개, 26.2%↑)')
LOG.append('Ⅲ 개선효과: 61개→77개 증가분(+16개, 16/61=26.2%) 병기')

# ── 3. Ⅴ 계량 성과분석(블록 49) 빈 칸 ───────────────────────
t49=X(ps[49],'.//hp:tbl')[0]
num_p=X(cell(t49,2,2),'hp:subList/hp:p')[0]
ana_p=X(cell(X(ps[51],'.//hp:tbl')[0],1,2),'hp:subList/hp:p')[0]
for r in (2,3):
    set_cell_text(cell(t49,r,3),'확인 필요',num_p)
    set_cell_text(cell(t49,r,4),'확인 필요',num_p)
set_cell_text(cell(t49,2,5),'※ 최종평가 결과는 공공데이터 전략위 및 국무회의 보고 후 3월에 공개될 예정 [확인 필요: 2025년 최종 평가결과 기재]',ana_p)
set_cell_text(cell(t49,3,5),'[확인 필요: 2025년 데이터기반행정 평가 결과 기재]',ana_p)
LOG.append('Ⅴ.1.가 계량 성과분석: 실적·달성률은 `확인 필요`, 성과분석 칸에 작년 초안의 ※ 문구(최종평가 결과 3월 공개 예정) 기입')

# ── 4. 글자 교정 ────────────────────────────────────────────
replace_text('‘ai행정 융합 기획','‘AI행정 융합 기획')
replace_text('전 직원 대상 ai 데이터 교육','전 직원 대상 AI 데이터 교육')

# ── 5. 새 블록 만들기 ──────────────────────────────────────
tmpl_head, tmpl_sub, tmpl_gap, tmpl_tbl = ps[36], ps[37], ps[52], ps[54]
_z=[200]
def fresh_ids(e):
    for t in X(e,'.//hp:tbl'): t.set('id',uid()); _z[0]+=1; t.set('zOrder',str(_z[0]))
    return e
def heading(num,title,page_break):
    p=nolines(copy.deepcopy(tmpl_head)); fresh_ids(p)
    cs=X(p,'.//hp:tc'); X(cs[1],'.//hp:t')[0].text=num; X(cs[2],'.//hp:t')[0].text=title
    p.set('pageBreak','1' if page_break else '0'); return p
def subheading(label,title):
    p=nolines(copy.deepcopy(tmpl_sub)); fresh_ids(p); cs=X(p,'.//hp:tc')
    X(cs[0],'.//hp:t')[0].text=label+'. '; ts=X(cs[1],'.//hp:t'); ts[1].text=title; return p
def gap(): return nolines(copy.deepcopy(tmpl_gap))
# ── 글머리 위계(양식 header.xml의 스타일 정의 그대로) ─────────────────
# 본문: □(스타일5) → ◯(6) → ●(7) → -(8) → ㆍ(9)   표 안: ●(17) → -(12) → *(13)
BODY={'□':('10','5','11'),'◯':('11','6','12'),'●':('12','7','14'),'-':('13','8','0'),'ㆍ':('14','9','16')}
CELL={'●':('1','17','18'),'-':('20','12','18'),'*':('21','13','22')}
def esc(t): return t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def body_p(marker,text):
    pp,st,ch=BODY[marker]
    return frag(f'<hp:p id="0" paraPrIDRef="{pp}" styleIDRef="{st}" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="{ch}"><hp:t>{esc(text)}</hp:t></hp:run></hp:p>')
def small_gap():
    return frag('<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="64"/></hp:p>')
def cell_p(marker,text):
    pp,st,ch=CELL[marker]
    return frag(f'<hp:p id="0" paraPrIDRef="{pp}" styleIDRef="{st}" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="{ch}"><hp:t>{esc(text)}</hp:t></hp:run></hp:p>')
W4=[7000,11500,17000,12759]
INDENT={'●':400,'-':1000,'*':1600}
def est_lines(items,width):
    n=0
    for mk,t in items:
        cpl=max(4,int((width-566-INDENT.get(mk,400))/(950 if mk=='*' else 1050))); w=sum(1 if ord(ch)>0x2e80 else 0.55 for ch in t); n+=max(1,math.ceil(w/cpl))
    return n
def table4(header,rows):
    """구분 | 추진방향 | 추진실적 | 추진성과 (주요사업 보고서 표 구조). 서식은 양식 블록 54를 복제.
    rows: [(라벨 줄들, 방향 [(마커,글)], 실적 [...], 성과 [...])]"""
    p=nolines(copy.deepcopy(tmpl_tbl)); fresh_ids(p); tbl=X(p,'.//hp:tbl')[0]
    trs=X(tbl,'hp:tr'); hdr,rowA,rowB=trs
    for tr in trs: tbl.remove(tr)
    hcells=X(hdr,'hp:tc'); mid=copy.deepcopy(hcells[1]); hdr.insert(list(hdr).index(hcells[2]),mid)  # 가운데 머리칸 1개 추가
    for i,tc in enumerate(X(hdr,'hp:tc')):
        X(tc,'.//hp:t')[0].text=header[i]; tc.find('hp:cellSz',NSM).set('width',str(W4[i])); tc.find('hp:cellAddr',NSM).set('colAddr',str(i))
    X(tbl,'.//hp:cellzone')[0].set('endColAddr','3'); tbl.set('colCnt','4'); tbl.append(hdr); total=1949
    for ri,(lab,c1,c2,c3) in enumerate(rows,start=1):
        src=rowB if ri==len(rows) else rowA; tr=copy.deepcopy(src); cs=X(tr,'hp:tc'); tr.insert(list(tr).index(cs[2]),copy.deepcopy(cs[1]))
        cs=X(tr,'hp:tc'); lines=max(len(lab),est_lines(c1,W4[1]),est_lines(c2,W4[2]),est_lines(c3,W4[3])); h=max(2800,lines*1500+800); total+=h
        for ci,(tc,content) in enumerate(zip(cs,(lab,c1,c2,c3))):
            sub=tc.find('hp:subList',NSM); sub.set('vertAlign','CENTER' if ci==0 else 'TOP')
            old=X(sub,'hp:p'); [sub.remove(o) for o in old]
            if ci==0:
                for line in content:
                    np_=nolines(copy.deepcopy(old[0])); X(np_,'.//hp:t')[0].text=line; sub.append(np_)
            else:
                for mk,line in content: sub.append(cell_p(mk,line))
            tc.find('hp:cellAddr',NSM).set('rowAddr',str(ri)); tc.find('hp:cellAddr',NSM).set('colAddr',str(ci))
            sz=tc.find('hp:cellSz',NSM); sz.set('width',str(W4[ci])); sz.set('height',str(h))
            m=tc.find('hp:cellMargin',NSM); m.set('top','283'); m.set('bottom','283'); m.set('left','283'); m.set('right','283')
        tbl.append(tr)
    tbl.set('rowCnt',str(len(rows)+1)); tbl.find('hp:sz',NSM).set('height',str(total)); return p
bin_items=[]
def picture(png,width=44000):
    from struct import unpack
    d=open(png,'rb').read(); pw,ph=unpack('>II',d[16:24]); h=int(width*ph/pw)
    n=103+len(bin_items); name=f'image{n}'; shutil.copy(png,f'{WORK}/BinData/{name}.png'); bin_items.append(name)
    pid,iid=uid(),uid(); dw,dh=pw*75,ph*75
    pic=f'''<hp:pic id="{pid}" zOrder="{_z[0]+50}" numberingType="PICTURE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" href="" groupLevel="0" instid="{iid}" reverse="0"><hp:offset x="0" y="0"/><hp:orgSz width="{width}" height="{h}"/><hp:curSz width="{width}" height="{h}"/><hp:flip horizontal="0" vertical="0"/><hp:rotationInfo angle="0" centerX="{width//2}" centerY="{h//2}" rotateimage="1"/><hp:renderingInfo><hc:transMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:scaMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:rotMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/></hp:renderingInfo><hc:img binaryItemIDRef="{name}" bright="0" contrast="0" effect="REAL_PIC" alpha="0"/><hp:imgRect><hc:pt0 x="0" y="0"/><hc:pt1 x="{width}" y="0"/><hc:pt2 x="{width}" y="{h}"/><hc:pt3 x="0" y="{h}"/></hp:imgRect><hp:imgClip left="0" right="{dw}" top="0" bottom="{dh}"/><hp:inMargin left="0" right="0" top="0" bottom="0"/><hp:imgDim dimwidth="{dw}" dimheight="{dh}"/><hp:effects/><hp:sz width="{width}" widthRelTo="ABSOLUTE" height="{h}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="PARA" vertAlign="TOP" horzAlign="CENTER" vertOffset="0" horzOffset="0"/><hp:outMargin left="0" right="0" top="0" bottom="0"/><hp:shapeComment>그림입니다.
원본 그림의 이름: {os.path.basename(png)}
원본 그림의 크기: 가로 {pw}pixel, 세로 {ph}pixel</hp:shapeComment></hp:pic>'''
    return frag(f'<hp:p id="0" paraPrIDRef="3" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="0">{pic}<hp:t/></hp:run></hp:p>')
def note(text):
    return frag(f'<hp:p id="0" paraPrIDRef="3" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="144"><hp:t>{esc(text)}</hp:t></hp:run></hp:p>')
def sub_pb(label,title,pb):
    p=subheading(label,title); p.set('pageBreak','1' if pb else '0'); return p
def text_block(items):
    out=[]
    for mk,t in items: out.append(body_p(mk,t))
    return out
H4=['구분','추진방향','추진실적','추진성과']
R='●'; D='-'; S='*'
FN='※ 출처: '
# ── 1.1 다. (양식 1.1 마지막 블록 뒤에 이어 붙임) ─────────────────────
add11=[gap(),subheading('다','개방 기반 및 데이터 품질관리 체계')]+text_block([
 ('□','총괄 부서 지정 및 메타관리시스템 기반 중장기 개방 체계 운영'),
 ('◯','총괄 부서를 지정하여 메타관리시스템 기반의 중장기 개방 계획 수립'),
 ('-','2026년까지 전체 개방 대상 테이블의 80% 조기 개방 검토 완료'),
 ('◯','데이터 표준 생성 시 상위 표준을 우선 준용'),
 ('◯','예방적 품질관리 및 데이터 값 진단을 정기적으로 수행')])+[
 note(FN+'2025년도 경영실적 평가 결과 보고서 1017쪽(평가단 의견). [확인 필요: 개방 계획서·품질관리 및 진단 결과 증빙]')]
# ── 1.2 ───────────────────────────────────────────────────────────────
add12=[heading('1.2',T12,True),gap(),subheading('가','민간 협업 및 데이터 제공 실적'),small_gap()]
add12+=text_block([('□','민간 AI 모델 개발 지원을 위한 데이터셋 제공')])+[small_gap(),
 table4(H4,[(['AI 학습용','데이터셋','제공'],
   [(R,'공공데이터 활용 증대를 위한 협력 체계 확대'),(R,'민간 기술과의 협력을 통한 데이터 활용성 제고')],
   [(R,'카카오 인공지능(AI) 모델 학습을 위한 데이터셋 제공 협약 체결(2회)'),(D,'텍스트 콘텐츠 약 8만 건, 미디어 콘텐츠 11만 건 제공'),
    (R,'한국민족문화대백과사전·향토문화전자대전의 데이터와 고화질 이미지를 소버린 AI(Sovereign AI) 개발에 지원'),
    (S,'[확인 필요: 주요사업 보고서의 백과사전 제공 건수(텍스트DB 약 74,000건, 이미지DB 약 71,700건)와 위 합계의 관계]')],
   [(R,'민간의 2차저작물 활용 지원'),(R,'대국민 정보 접근성 강화'),(R,'모범적 민관 협력 모델 구축'),(D,'지속적인 확대 노력 예정')])]),
 small_gap()]
add12+=text_block([('□','데이터 활용 의사가 있는 기업·시민 대상 활용 확산')])+[small_gap(),
 table4(H4,[
  (['데이터 활용','행사 운영'],
   [(R,'데이터 활용 의사가 있는 기업과 시민의 참여 유도')],
   [(R,'사전 신청제로 참여자를 선별하여 데이터 활용 행사 운영')],
   [(R,'행사 후 만족도 92.6%'),(R,'데이터 이해도 제고 96.2%')]),
  (['지역 협업','합동 설명회'],
   [(R,'공공데이터 활용 증대를 위한 협력 체계 확대')],
   [(R,'성남시 소재 5개 공공기관 공공데이터 합동 설명회 개최'),(D,'성남시 공공기관 최초 합동 설명회')],
   [(R,'민간 기업·개인, 기관별 공공데이터 담당자 등 67명 참석')])]),
 note(FN+'2025년도 경영실적 평가 결과 보고서 1017쪽(사전 신청제 행사), 2025년도 경영실적보고서(성남시 설명회). [확인 필요: 두 행사의 동일 여부, 행사 결과보고·참석자 명단]')]
add12+=[sub_pb('나','개방·제공 규모 현황',True),small_gap(),picture(f'{FIG}/그림1_개방제공규모.png'),small_gap()]
add12+=text_block([
 ('□','공공데이터 개방 및 민간 제공 규모 확대'),
 ('◯','공공데이터 목록 개방: 61개(’24년까지) → 77개(’25년), +16개(26.2%↑)'),
 ('-','데이터 양적 확대 개방'),
 ('-','국립민속박물관, 국립새만금간척박물관 등 총 11건 제공(’24년 실적)'),
 ('◯','카카오 AI 모델 학습용 데이터셋 제공: 텍스트 콘텐츠 약 8만 건, 미디어 콘텐츠 11만 건'),
 ('-','협약 2회 체결을 통해 민간의 2차저작물 활용 지원 및 대국민 정보 접근성 강화'),
 ('◯','공공데이터 활용 증대를 위한 협력 체계 확대 지속 추진')])+[
 note(FN+'2025년도 경영실적보고서(창업 및 경제활성화) 주요 추진실적, 카카오 데이터셋 제공 협약 실적')]
# ── 1.3 ───────────────────────────────────────────────────────────────
add13=[heading('1.3',T13,True),gap(),subheading('가','역량 강화 및 홍보 실적'),small_gap()]
add13+=text_block([('□','데이터기반행정 역량 강화를 위한 교육')])+[small_gap(),
 table4(H4,[
  (['담당자','교육'],
   [(R,'공공데이터 기반 역량 강화')],
   [(R,'공공데이터 기관 담당자 교육'),(D,'‘AI행정 융합 기획’(16시간) 이수(7.7.~7.8.)')],
   [(R,'교육 이수를 통한 담당자 역량 강화')]),
  (['전 직원','교육'],
   [(R,'데이터기반행정 확산을 위한 공감대 확산')],
   [(R,'전 직원 대상 AI 데이터 교육 실시'),(D,'‘데이터기반행정과 데이터 리터러시’(교직원 191명 수료)')],
   [(R,'전 직원 대상 공공데이터 교육을 통한 데이터기반행정 역량 강화')]),
  (['역량 진단'],
   [(R,'데이터 활용역량진단 설문조사를 통한 성과 측정')],
   [(R,'[확인 필요: 데이터 활용역량진단 설문조사 실시 여부·결과]')],
   [(R,'[확인 필요: 진단 결과를 교육 과정에 반영한 실적]')])]),
 small_gap()]
add13+=text_block([('□','교육 및 카드뉴스 배포 등 홍보 강화')])+[small_gap(),
 table4(H4,[(['홍보','강화'],
   [(R,'데이터기반행정에 대한 구성원 인식 제고')],
   [(R,'교육 및 카드뉴스 배포 등 홍보 강화'),(D,'인스타그램 등 카드뉴스 2,066회 열람')],
   [(R,'내부 구성원 인식 제고'),(D,'데이터기반행정 확산을 위한 공감대 확산 필요')])]),
 note(FN+'2025년도 경영실적보고서(창업 및 경제활성화) 1.1 및 Ⅴ.1. [확인 필요: 교육 이수 명단(191명)·교육 일정 증빙]')]
add13+=[sub_pb('나','성과 환류 체계 (선순환 구조 체계화)',True),small_gap(),picture(f'{FIG}/그림2_개방활용환류_선순환.png',40000),small_gap()]
add13+=text_block([
 ('□','“수요 발굴 → 우선 개방 → 활용 촉진 → 성과 환류”의 선순환 구조 체계화'),
 ('◯','수요 기반 전략적·집중적 개방 전략 강화'),
 ('-','고수요 데이터 선별·집중 개방'),
 ('-','데이터 큐레이션·컨설팅 진행, 표준화 기반 제공 확대'),
 ('◯','부서 간 데이터 공유 활성화를 통한 데이터 기반 행정 확산'),
 ('-','공통 데이터 플랫폼·결합 체계 강화'),
 ('-','정책 기획 단계부터 데이터 활용 의무화 및 전문직군 제도화'),
 ('◯','직무·직급별 데이터 역량 강화 체계화 및 데이터 정합성·정확성 점검 프로세스 상시화'),
 ('◯','전년도 평가 결과 분석을 통한 환류')])+[
 note(FN+'2025년도 경영실적보고서(창업 및 경제활성화) Ⅰ.1 성과측정(모니터링), Ⅴ.2 향후 개선과제 및 추진계획')]
LOG.append('Ⅳ 1.1 다(신설 소항목: 개방 기반·품질관리), 1.2·1.3 신설 — 설명 텍스트는 양식 글머리 위계(□◯●-ㆍ, 표 안 ●-*)로 작성, 구분/추진방향/추진실적/추진성과 표(주요사업 보고서 구조) 사용')
# ── 삽입 ──────────────────────────────────────────────────────────────
i46=list(root).index(ps[46])+1
for k,e in enumerate(add11): root.insert(i46+k,e)
anchor=ps[47]; idx=list(root).index(anchor)
for k,e in enumerate(add12+add13): root.insert(idx+k,e)
anchor.set('pageBreak','1'); LOG.append('Ⅴ 성과분석 및 환류: 새 쪽에서 시작하도록 쪽 나눔 지정')

tree.write(sec_path,xml_declaration=True,encoding='UTF-8',standalone=True)
# 매니페스트에 그림 등록
hp=f'{WORK}/Contents/content.hpf'; s=open(hp,encoding='utf8').read()
add=''.join(f'<opf:item id="{n}" href="BinData/{n}.png" media-type="image/png" isEmbeded="1"/>' for n in bin_items)
assert s.count('</opf:manifest>')==1; open(hp,'w',encoding='utf8').write(s.replace('</opf:manifest>',add+'</opf:manifest>'))
# 미리보기 글자
t2=etree.parse(f'{WORK}/Contents/section0.xml').getroot()
prev='\n'.join(x.strip() for x in X(t2,'.//hp:t/text()') if x.strip())[:900]
open(f'{WORK}/Preview/PrvText.txt','w',encoding='utf8').write(prev)
subprocess.check_call([sys.executable,'-I',os.path.join(os.path.dirname(os.path.abspath(__file__)),'hwpx_묶기.py'),WORK,OUT])
open(OUT+'.변경목록.txt','w',encoding='utf8').write('\n'.join(LOG)+'\n'); print('\n'.join(LOG))
